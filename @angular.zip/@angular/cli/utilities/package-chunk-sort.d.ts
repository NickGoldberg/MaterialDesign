export declare function packageChunkSort(appConfig: any): (left: any, right: any) => 0 | 1 | -1;
